<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.12.2" name="TilesetWater" tilewidth="16" tileheight="16" tilecount="476" columns="28">
 <image source="../../New folder (2)/TilesetWater.png" width="448" height="272"/>
</tileset>
