<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.12.2" name="Bitmask references 1" tilewidth="16" tileheight="16" tilecount="480" columns="30">
 <image source="../Assets/outside_basic/Tilesets/Bitmask references 1.png" width="480" height="256"/>
</tileset>
